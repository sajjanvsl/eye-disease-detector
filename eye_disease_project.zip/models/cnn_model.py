import torch.nn as nn
from torchvision import models

class EyeCNN(nn.Module):
    def __init__(self, num_classes):
        super(EyeCNN, self).__init__()
        self.model = models.resnet18(pretrained=True)
        self.model.fc = nn.Linear(self.model.fc.in_features, num_classes)

    def forward(self, x):
        return self.model(x)
